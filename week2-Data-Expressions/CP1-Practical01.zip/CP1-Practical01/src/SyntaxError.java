/*
public class SyntaxError {
    public static void main(String[] args) {
        System.out.println("If you are reading this output ");
        System.in.println(in the execution "window then you have) ;
        System.out.println(successfully removed all the syntax errors
)
    }
}
*/
