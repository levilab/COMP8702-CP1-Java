/*
public class DebugThree {
        public statoc void main(String[] args) {
            Systemout.println("This output ");
            Systemout.print("is on the same line as the last one.");
            Systemout.println("But this is on a new line.);
        }
        }
*/
