/*
// This program displays a greeting
public class DebugOne {
   public void main(String[] args) {
      System.out.println("Hello, CP1")
   }
}
*/
