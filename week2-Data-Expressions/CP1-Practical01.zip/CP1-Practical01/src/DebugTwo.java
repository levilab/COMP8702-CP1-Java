/*
// This program displays some output
public class DebugTwo {
    public static void Main(String[] args)
    {
        System.outprintln("Java programming is fun.")
        System.outprintln("Getting a program to work);
                System.outprintln(can be a challenge,");
                        System.outprintln("but when everything works correctly,");
        System.outprintln(it's very satisfying");
    }
}
*/
