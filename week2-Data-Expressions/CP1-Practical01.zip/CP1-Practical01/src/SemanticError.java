public class SemanticError {
   public static void main(String[] args) {
//      System.out.println(3 + "8 is greater than 10, and");
//      System.out.println("9" / 3 + "equals 3");
//      System.out.println("Well" * "done!");
   }
}
